# desafios-dio

Pacote criado de funções que são pedidos nos desafios 1 e 2.
Esse pacote existe para aprendizado.

## Instalação

use o pacote pip para instalar o desafios-dio

'''hash
pip install desafios-dio
'''

## Autor

José Francisco Azevedo da Silva